<?php
// Incloure configuració
require_once '../config.php';

// Comprovar si l'usuari és admin
if (!isset($_SESSION['usuari_id']) || $_SESSION['rol'] !== 'admin') {
    redirect("../login.php");
}

$missatge = '';

// Obtenir tots els usuaris
$sql = "SELECT id, nom, email, rol, data_registre FROM usuaris ORDER BY data_registre DESC";
$result = $conn->query($sql);
$usuaris = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $usuaris[] = $row;
    }
}

// Eliminar usuari
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['eliminar'])) {
    $usuari_id = $_POST['usuari_id'];

    // No permetre eliminar l'admin actual
    if ($usuari_id == $_SESSION['usuari_id']) {
        $missatge = "No pots eliminar el teu propi compte.";
    } else {
        $sql = "DELETE FROM usuaris WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $usuari_id);
        if ($stmt->execute()) {
            $missatge = "Usuari eliminat amb èxit.";
        } else {
            $missatge = "Error: " . $stmt->error;
        }
        $stmt->close();
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="ca">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestió d'Usuaris - Cyberspot</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css.css">
</head>
<body>
    <?php include '../barranav.php'; ?>

    <div class="container mt-5">
        <h1>Gestió d'Usuaris</h1>

        <?php if (!empty($missatge)): ?>
            <div class="alert alert-<?php echo strpos($missatge, 'èxit') !== false ? 'success' : 'danger'; ?>">
                <?php echo $missatge; ?>
            </div>
        <?php endif; ?>

        <a href="afegirusuari.php" class="btn btn-primary mb-3">Afegir Usuari</a>

        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nom</th>
                        <th>Email</th>
                        <th>Rol</th>
                        <th>Data Registre</th>
                        <th>Accions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($usuaris as $usuari): ?>
                        <tr>
                            <td><?php echo $usuari['id']; ?></td>
                            <td><?php echo $usuari['nom']; ?></td>
                            <td><?php echo $usuari['email']; ?></td>
                            <td><?php echo $usuari['rol']; ?></td>
                            <td><?php echo $usuari['data_registre']; ?></td>
                            <td>
                                <form method="post" action="gestiousuaris.php" class="d-inline">
                                    <input type="hidden" name="usuari_id" value="<?php echo $usuari['id']; ?>">
                                    <button type="submit" name="eliminar" class="btn btn-sm btn-danger"
                                            onclick="return confirm('Estàs segur que vols eliminar aquest usuari?');">
                                        Eliminar
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <?php include '../foot.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>