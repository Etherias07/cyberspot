<?php
// Incloure configuració
require_once 'config.php';

$missatge = '';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nom = trim($_POST['nom']);
    $email = trim($_POST['email']);
    $contrasenya = $_POST['contrasenya'];
    $confirmar_contrasenya = $_POST['confirmar_contrasenya'];

    if (empty($nom) || empty($email) || empty($contrasenya) || empty($confirmar_contrasenya)) {
        $missatge = "Si us plau, omple tots els camps.";
    } elseif ($contrasenya !== $confirmar_contrasenya) {
        $missatge = "Les contrasenyes no coincideixen.";
    } else {
        // Comprovar si l'email ja existeix
        $sql = "SELECT id FROM usuaris WHERE email = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $missatge = "Aquest email ja està registrat.";
        } else {
            // Hash de la contrasenya
            $hashed_password = password_hash($contrasenya, PASSWORD_DEFAULT);

            // Inserir usuari (rol per defecte: client)
            $sql = "INSERT INTO usuaris (nom, email, contrasenya, rol) VALUES (?, ?, ?, 'client')";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sss", $nom, $email, $hashed_password);

            if ($stmt->execute()) {
                $missatge = "Registre realitzat amb èxit! Ja pots entrar.";
                redirect("login.php");
            } else {
                $missatge = "Error: " . $stmt->error;
            }
        }
        $stmt->close();
    }
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="ca">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registre - Cyberspot</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css.css">
</head>
<body>
    <?php include 'barranav.php'; ?>

    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h3 class="text-center">Registre</h3>
                    </div>
                    <div class="card-body">
                        <?php if (!empty($missatge)): ?>
                            <div class="alert alert-<?php echo strpos($missatge, 'èxit') !== false ? 'success' : 'danger'; ?>">
                                <?php echo $missatge; ?>
                            </div>
                        <?php endif; ?>
                        <form method="post" action="registre.php">
                            <div class="mb-3">
                                <label for="nom" class="form-label">Nom:</label>
                                <input type="text" class="form-control" id="nom" name="nom" required>
                            </div>
                            <div class="mb-3">
                                <label for="email" class="form-label">Email:</label>
                                <input type="email" class="form-control" id="email" name="email" required>
                            </div>
                            <div class="mb-3">
                                <label for="contrasenya" class="form-label">Contrasenya:</label>
                                <input type="password" class="form-control" id="contrasenya" name="contrasenya" required>
                            </div>
                            <div class="mb-3">
                                <label for="confirmar_contrasenya" class="form-label">Confirmar Contrasenya:</label>
                                <input type="password" class="form-control" id="confirmar_contrasenya" name="confirmar_contrasenya" required>
                            </div>
                            <div class="d-grid">
                                <button type="submit" class="btn btn-primary">Registrar-se</button>
                            </div>
                        </form>
                        <div class="mt-3 text-center">
                            <p>Ja tens compte? <a href="login.php">Entra</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php include 'foot.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>