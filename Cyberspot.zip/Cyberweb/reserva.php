<?php
// Incloure configuració
require_once 'config.php';

// Missatge per a mostrar errors o èxits
$missatge = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nom = trim($_POST['nom']);
    $data = $_POST['data'];
    $hora_inici = $_POST['hora_inici'];
    $hora_fi = $_POST['hora_fi'];
    $pc_id = $_POST['pc_id'];
    $usuari_id = $_SESSION['usuari_id'] ?? null;

    // Validar camps
    if (empty($nom) || empty($data) || empty($hora_inici) || empty($hora_fi) || empty($pc_id)) {
        $missatge = "Si us plau, omple tots els camps.";
    } else {
        // Comprovar si el PC està disponible en aquesta franja horària
        $sql = "SELECT COUNT(*) AS count FROM reserves
                WHERE pc_id = ? AND data = ? AND
                ((hora_inici <= ? AND hora_fi >= ?) OR
                 (hora_inici <= ? AND hora_fi >= ?) OR
                 (hora_inici >= ? AND hora_fi <= ?))";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("isssssss", $pc_id, $data, $hora_inici, $hora_inici, $hora_fi, $hora_fi, $hora_inici, $hora_fi);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();

        if ($row['count'] > 0) {
            $missatge = "El PC seleccionat no està disponible en aquesta franja horària.";
        } else {
            // Inserir reserva
            $sql = "INSERT INTO reserves (usuari_id, pc_id, data, hora_inici, hora_fi, estat)
                    VALUES (?, ?, ?, ?, ?, 'pendent')";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("iisss", $usuari_id, $pc_id, $data, $hora_inici, $hora_fi);

            if ($stmt->execute()) {
                $missatge = "Reserva realitzada amb èxit!";
            } else {
                $missatge = "Error: " . $stmt->error;
            }
        }
        $stmt->close();
    }
}

// Obtenir llista de PCs
$sql = "SELECT id, nom, tipus FROM pcs";
$result = $conn->query($sql);
$pcs = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $pcs[] = $row;
    }
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="ca">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reserva un PC - Cyberspot</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css.css">
</head>
<body>
    <?php include 'barranav.php'; ?>

    <div class="container mt-5">
        <h1>Reserva un PC</h1>
        <?php if (!empty($missatge)): ?>
            <div class="alert alert-<?php echo strpos($missatge, 'èxit') !== false ? 'success' : 'danger'; ?>">
                <?php echo $missatge; ?>
            </div>
        <?php endif; ?>

        <form method="post" action="reserva.php">
            <div class="mb-3">
                <label for="nom" class="form-label">Nom:</label>
                <input type="text" class="form-control" id="nom" name="nom" required
                       value="<?php echo isset($_SESSION['nom']) ? $_SESSION['nom'] : ''; ?>">
            </div>
            <div class="mb-3">
                <label for="data" class="form-label">Data:</label>
                <input type="date" class="form-control" id="data" name="data" required
                       min="<?php echo date('Y-m-d'); ?>" max="<?php echo date('Y-m-d', strtotime('+1 month')); ?>">
            </div>
            <div class="row mb-3">
                <div class="col">
                    <label for="hora_inici" class="form-label">Hora d'Inici:</label>
                    <input type="time" class="form-control" id="hora_inici" name="hora_inici" required>
                </div>
                <div class="col">
                    <label for="hora_fi" class="form-label">Hora de Fi:</label>
                    <input type="time" class="form-control" id="hora_fi" name="hora_fi" required>
                </div>
            </div>
            <div class="mb-3">
                <label for="pc_id" class="form-label">PC:</label>
                <select class="form-select" id="pc_id" name="pc_id" required>
                    <option value="">Selecciona un PC</option>
                    <?php foreach ($pcs as $pc): ?>
                        <option value="<?php echo $pc['id']; ?>">
                            <?php echo $pc['nom'] . " (" . $pc['tipus'] . ")"; ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Reserva</button>
        </form>

        <div class="mt-4">
            <h3>Disponibilitat</h3>
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>PC</th>
                            <th>Tipus</th>
                            <th>Estat</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($pcs as $pc): ?>
                            <tr>
                                <td><?php echo $pc['nom']; ?></td>
                                <td><?php echo $pc['tipus']; ?></td>
                                <td>
                                    <?php
                                    // Simplificació: Mostrar estat com a "lliure" per defecte
                                    echo "Lliure";
                                    ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <?php include 'foot.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>