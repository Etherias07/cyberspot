<?php
// Incloure configuració i iniciar sessió
require_once 'config.php';
?>
<!DOCTYPE html>
<html lang="ca">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cyberspot - Cibercafè Modern</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css.css">
</head>
<body>
    <?php include 'barranav.php'; ?>

    <div class="container mt-5">
        <div class="jumbotron bg-light p-5 rounded-lg m-3">
            <h1 class="display-4">Benvingut a Cyberspot!</h1>
            <p class="lead">El cibercafè modern on pots jugar, treballar, estudiar i connectar-te amb els teus amics.</p>
            <hr class="my-4">
            <p>Oferim PCs gaming d'alta gamma, connexió a Internet d'1Gbps, i un espai còmode per a totes les teves necessitats digitals.</p>
            <a class="btn btn-primary btn-lg" href="reserva.php" role="button">Reserva un PC ara</a>
        </div>

        <div class="row">
            <div class="col-md-4">
                <div class="card mb-4">
                    <img src="ChatGPT1 Image 13 may 2026, 23_12_19.png" class="card-img-top" alt="Zona Gaming">
                    <div class="card-body">
                        <h5 class="card-title">Zona Gaming</h5>
                        <p class="card-text">PCs amb RTX 3060, Valorant, Minecraft, Fortnite, i molts més jocs.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card mb-4">
                    <img src="ChatGPT2 Image 13 may 2026, 23_12_19.png" class="card-img-top" alt="Zona Estudi">
                    <div class="card-body">
                        <h5 class="card-title">Zona d'Estudi</h5>
                        <p class="card-text">Taules tranquil·les, punts de càrrega, i PCs per a treballar o estudiar.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card mb-4">
                    <img src="ChatGPT3 Image 13 may 2026, 23_12_19.png" class="card-img-top" alt="Cafeteria">
                    <div class="card-body">
                        <h5 class="card-title">Cafeteria</h5>
                        <p class="card-text">Snacks, begudes, i un ambient acollidor per a descansar.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php include 'foot.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>