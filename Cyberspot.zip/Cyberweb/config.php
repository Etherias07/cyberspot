<?php
// =============================================
// CONFIGURACIO DE LA BASE DE DADES - CYBERSPOT
// =============================================

// Credencials de la base de dades (Dinahosting)
define('DB_SERVER', 'localhost'); 
define('DB_USERNAME', 'cyberspot'); 
define('DB_PASSWORD', 'Nunchacku1972&'); 
define('DB_NAME', 'cyber_bd'); 

// Intentar connexio a la base de dades
$conn = new mysqli(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

// Comprovar connexio
if ($conn->connect_error) {
    die("Error de connexio a la base de dades: " . $conn->connect_error);
}

// Iniciar sessio
session_start();

// Funcio per a redirigir
function redirect($url) {
    header("Location: $url");
    exit();
}
?>