<?php
// Incloure configuració
require_once '../config.php';

// Comprovar si l'usuari és admin
if (!isset($_SESSION['usuari_id']) || $_SESSION['rol'] !== 'admin') {
    redirect("../login.php");
}

// Obtenir estadístiques
$sql = "SELECT COUNT(*) AS total_reserves FROM reserves";
$result = $conn->query($sql);
$total_reserves = $result->fetch_assoc()['total_reserves'];

$sql = "SELECT COUNT(*) AS total_usuaris FROM usuaris";
$result = $conn->query($sql);
$total_usuaris = $result->fetch_assoc()['total_usuaris'];

$sql = "SELECT COUNT(*) AS total_pcs FROM pcs";
$result = $conn->query($sql);
$total_pcs = $result->fetch_assoc()['total_pcs'];

$conn->close();
?>

<!DOCTYPE html>
<html lang="ca">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panell d'Administració - Cyberspot</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css.css">
</head>
<body>
    <?php include '../barranav.php'; ?>

    <div class="container mt-5">
        <h1>Panell d'Administració</h1>

        <div class="row mb-4">
            <div class="col-md-4">
                <div class="card text-white bg-primary mb-3">
                    <div class="card-body">
                        <h5 class="card-title">Reserves Totals</h5>
                        <p class="card-text fs-3"><?php echo $total_reserves; ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card text-white bg-success mb-3">
                    <div class="card-body">
                        <h5 class="card-title">Usuaris Registrats</h5>
                        <p class="card-text fs-3"><?php echo $total_usuaris; ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card text-white bg-info mb-3">
                    <div class="card-body">
                        <h5 class="card-title">PCs Disponibles</h5>
                        <p class="card-text fs-3"><?php echo $total_pcs; ?></p>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6">
                <div class="card mb-4">
                    <div class="card-header">
                        <h5>Gestionar Reserves</h5>
                    </div>
                    <div class="card-body">
                        <a href="gestioreservesadmin.php" class="btn btn-primary">Veure Reserves</a>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card mb-4">
                    <div class="card-header">
                        <h5>Gestionar Usuaris</h5>
                    </div>
                    <div class="card-body">
                        <a href="gestiousuaris.php" class="btn btn-primary">Veure Usuaris</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php include '../foot.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>