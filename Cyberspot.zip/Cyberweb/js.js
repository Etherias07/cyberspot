/* =============================================
   SCRIPTS JAVASCRIPT - CYBERSPOT
   ============================================= */

// Funció per a mostrar missatges temporals
function showTemporaryMessage(message, isSuccess = true) {
    const alertContainer = document.createElement('div');
    alertContainer.className = `alert alert-${isSuccess ? 'success' : 'danger'} alert-dismissible fade show`;
    alertContainer.role = 'alert';
    alertContainer.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    `;

    // Afegir l'alerta al contingut
    const container = document.querySelector('.container') || document.body;
    container.insertBefore(alertContainer, container.firstChild);

    // Eliminar l'alerta després de 5 segons
    setTimeout(() => {
        alertContainer.remove();
    }, 5000);
}

// Validació del formulari de reserves
document.addEventListener('DOMContentLoaded', function() {
    const reservaForm = document.querySelector('form[action="reserva.php"]');
    if (reservaForm) {
        reservaForm.addEventListener('submit', function(e) {
            const horaInici = document.getElementById('hora_inici').value;
            const horaFi = document.getElementById('hora_fi').value;

            if (horaInici >= horaFi) {
                e.preventDefault();
                showTemporaryMessage('L\'hora de fi ha de ser posterior a l\'hora d\'inici.', false);
            }
        });
    }

    // Validació del formulari de registre
    const registreForm = document.querySelector('form[action="registre.php"]');
    if (registreForm) {
        registreForm.addEventListener('submit', function(e) {
            const contrasenya = document.getElementById('contrasenya').value;
            const confirmarContrasenya = document.getElementById('confirmar_contrasenya').value;

            if (contrasenya !== confirmarContrasenya) {
                e.preventDefault();
                showTemporaryMessage('Les contrasenyes no coincideixen.', false);
            } else if (contrasenya.length < 6) {
                e.preventDefault();
                showTemporaryMessage('La contrasenya ha de tenir almenys 6 caràcters.', false);
            }
        });
    }
});