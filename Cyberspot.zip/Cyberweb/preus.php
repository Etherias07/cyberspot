<?php
// Incloure configuració
require_once 'config.php';
?>
<!DOCTYPE html>
<html lang="ca">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Preus - Cyberspot</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css.css">
</head>
<body>
    <?php include 'barranav.php'; ?>

    <div class="container mt-5">
        <h1>Preus</h1>
        <div class="row">
            <div class="col-md-6">
                <div class="card mb-4">
                    <div class="card-header bg-primary text-white">
                        <h3>PCs Gaming</h3>
                    </div>
                    <div class="card-body">
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item">1 hora: <strong>5€</strong></li>
                            <li class="list-group-item">2 hores: <strong>9€</strong></li>
                            <li class="list-group-item">4 hores: <strong>15€</strong></li>
                            <li class="list-group-item">Dia complet: <strong>25€</strong></li>
                        </ul>
                        <p class="mt-3">PCs amb RTX 3060, 16GB RAM, i monitor de 24".</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card mb-4">
                    <div class="card-header bg-success text-white">
                        <h3>PCs d'Estudi/Treball</h3>
                    </div>
                    <div class="card-body">
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item">1 hora: <strong>3€</strong></li>
                            <li class="list-group-item">2 hores: <strong>5€</strong></li>
                            <li class="list-group-item">4 hores: <strong>8€</strong></li>
                            <li class="list-group-item">Dia complet: <strong>12€</strong></li>
                        </ul>
                        <p class="mt-3">PCs amb Ubuntu, 8GB RAM, i ofimàtica preinstal·lada.</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header bg-info text-white">
                        <h3>Serveis Addicionals</h3>
                    </div>
                    <div class="card-body">
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item">Impressió: <strong>0,20€/pàgina</strong></li>
                            <li class="list-group-item">Escaneig: <strong>0,50€/document</strong></li>
                            <li class="list-group-item">Begudes i snacks: <strong>2€ - 5€</strong></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php include 'foot.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>