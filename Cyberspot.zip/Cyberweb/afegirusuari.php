<?php
// Incloure configuració
require_once '../config.php';

// Comprovar si l'usuari és admin
if (!isset($_SESSION['usuari_id']) || $_SESSION['rol'] !== 'admin') {
    redirect("../login.php");
}

$missatge = '';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nom = trim($_POST['nom']);
    $email = trim($_POST['email']);
    $contrasenya = $_POST['contrasenya'];
    $rol = $_POST['rol'];

    if (empty($nom) || empty($email) || empty($contrasenya)) {
        $missatge = "Si us plau, omple tots els camps.";
    } else {
        // Comprovar si l'email ja existeix
        $sql = "SELECT id FROM usuaris WHERE email = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $missatge = "Aquest email ja està registrat.";
        } else {
            // Hash de la contrasenya
            $hashed_password = password_hash($contrasenya, PASSWORD_DEFAULT);

            // Inserir usuari
            $sql = "INSERT INTO usuaris (nom, email, contrasenya, rol) VALUES (?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssss", $nom, $email, $hashed_password, $rol);

            if ($stmt->execute()) {
                $missatge = "Usuari afegit amb èxit!";
            } else {
                $missatge = "Error: " . $stmt->error;
            }
        }
        $stmt->close();
    }
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="ca">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Afegir Usuari - Cyberspot</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css.css">
</head>
<body>
    <?php include '../barranav.php'; ?>

    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h3 class="text-center">Afegir Usuari</h3>
                    </div>
                    <div class="card-body">
                        <?php if (!empty($missatge)): ?>
                            <div class="alert alert-<?php echo strpos($missatge, 'èxit') !== false ? 'success' : 'danger'; ?>">
                                <?php echo $missatge; ?>
                            </div>
                        <?php endif; ?>
                        <form method="post" action="afegirusuari.php">
                            <div class="mb-3">
                                <label for="nom" class="form-label">Nom:</label>
                                <input type="text" class="form-control" id="nom" name="nom" required>
                            </div>
                            <div class="mb-3">
                                <label for="email" class="form-label">Email:</label>
                                <input type="email" class="form-control" id="email" name="email" required>
                            </div>
                            <div class="mb-3">
                                <label for="contrasenya" class="form-label">Contrasenya:</label>
                                <input type="password" class="form-control" id="contrasenya" name="contrasenya" required>
                            </div>
                            <div class="mb-3">
                                <label for="rol" class="form-label">Rol:</label>
                                <select class="form-select" id="rol" name="rol" required>
                                    <option value="client">Client</option>
                                    <option value="admin">Administrador</option>
                                </select>
                            </div>
                            <div class="d-grid">
                                <button type="submit" class="btn btn-primary">Afegir Usuari</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php include '../foot.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>