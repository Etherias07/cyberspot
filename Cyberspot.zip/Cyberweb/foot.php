<footer class="bg-dark text-white text-center py-4">
    <div class="container">
        <p>&copy; <?php echo date('Y'); ?> Cyberspot. Tots els drets reservats.</p>
        <p>
            <a href="#" class="text-white me-2">Política de Privacitat</a>
            <a href="#" class="text-white me-2">Termes de Servei</a>
            <a href="#" class="text-white">Contacte</a>
        </p>
    </div>
</footer>