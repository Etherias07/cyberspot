<?php
// Incloure configuració
require_once 'config.php';

$missatge = '';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST['email']);
    $contrasenya = $_POST['contrasenya'];

    if (empty($email) || empty($contrasenya)) {
        $missatge = "Si us plau, omple tots els camps.";
    } else {
        // Comprovar usuari a la BD
        $sql = "SELECT id, nom, email, contrasenya, rol FROM usuaris WHERE email = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows == 1) {
            $usuari = $result->fetch_assoc();
            if (password_verify($contrasenya, $usuari['contrasenya'])) {
                $_SESSION['usuari_id'] = $usuari['id'];
                $_SESSION['nom'] = $usuari['nom'];
                $_SESSION['email'] = $usuari['email'];
                $_SESSION['rol'] = $usuari['rol'];
                redirect("index.php");
            } else {
                $missatge = "Contrasenya incorrecta.";
            }
        } else {
            $missatge = "No s'ha trobat cap compte amb aquest email.";
        }
        $stmt->close();
    }
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="ca">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Entrar - Cyberspot</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css.css">
</head>
<body>
    <?php include 'barranav.php'; ?>

    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h3 class="text-center">Entrar</h3>
                    </div>
                    <div class="card-body">
                        <?php if (!empty($missatge)): ?>
                            <div class="alert alert-danger"><?php echo $missatge; ?></div>
                        <?php endif; ?>
                        <form method="post" action="login.php">
                            <div class="mb-3">
                                <label for="email" class="form-label">Email:</label>
                                <input type="email" class="form-control" id="email" name="email" required>
                            </div>
                            <div class="mb-3">
                                <label for="contrasenya" class="form-label">Contrasenya:</label>
                                <input type="password" class="form-control" id="contrasenya" name="contrasenya" required>
                            </div>
                            <div class="d-grid">
                                <button type="submit" class="btn btn-primary">Entrar</button>
                            </div>
                        </form>
                        <div class="mt-3 text-center">
                            <p>No tens compte? <a href="registre.php">Registra't</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php include 'foot.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>