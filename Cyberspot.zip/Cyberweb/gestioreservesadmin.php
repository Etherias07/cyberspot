<?php
// Incloure configuració
require_once '../config.php';

// Comprovar si l'usuari és admin
if (!isset($_SESSION['usuari_id']) || $_SESSION['rol'] !== 'admin') {
    redirect("../login.php");
}

// Obtenir totes les reserves
$sql = "SELECT r.id, u.nom AS usuari, p.nom AS pc, r.data, r.hora_inici, r.hora_fi, r.estat
        FROM reserves r
        LEFT JOIN usuaris u ON r.usuari_id = u.id
        LEFT JOIN pcs p ON r.pc_id = p.id
        ORDER BY r.data, r.hora_inici";
$result = $conn->query($sql);
$reserves = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $reserves[] = $row;
    }
}

// Actualitzar estat de la reserva
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['actualitzar'])) {
    $reserva_id = $_POST['reserva_id'];
    $estat = $_POST['estat'];

    $sql = "UPDATE reserves SET estat = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("si", $estat, $reserva_id);
    $stmt->execute();
    $stmt->close();

    // Refrescar la pàgina
    redirect("gestioreservesadmin.php");
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="ca">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestió de Reserves - Cyberspot</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <?php include '../barranav.php'; ?>

    <div class="container mt-5">
        <h1>Gestió de Reserves</h1>

        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Usuari</th>
                        <th>PC</th>
                        <th>Data</th>
                        <th>Hora Inici</th>
                        <th>Hora Fi</th>
                        <th>Estat</th>
                        <th>Accions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($reserves as $reserva): ?>
                        <tr>
                            <td><?php echo $reserva['id']; ?></td>
                            <td><?php echo $reserva['usuari'] ?: 'Invitat'; ?></td>
                            <td><?php echo $reserva['pc']; ?></td>
                            <td><?php echo $reserva['data']; ?></td>
                            <td><?php echo $reserva['hora_inici']; ?></td>
                            <td><?php echo $reserva['hora_fi']; ?></td>
                            <td><?php echo $reserva['estat']; ?></td>
                            <td>
                                <form method="post" action="gestioreserves.php" class="d-inline">
                                    <input type="hidden" name="reserva_id" value="<?php echo $reserva['id']; ?>">
                                    <select name="estat" class="form-select form-select-sm">
                                        <option value="pendent" <?php echo $reserva['estat'] == 'pendent' ? 'selected' : ''; ?>>Pendent</option>
                                        <option value="confirmada" <?php echo $reserva['estat'] == 'confirmada' ? 'selected' : ''; ?>>Confirmada</option>
                                        <option value="cancelada" <?php echo $reserva['estat'] == 'cancelada' ? 'selected' : ''; ?>>Cancel·lada</option>
                                        <option value="finalitzada" <?php echo $reserva['estat'] == 'finalitzada' ? 'selected' : ''; ?>>Finalitzada</option>
                                    </select>
                                    <button type="submit" name="actualitzar" class="btn btn-sm btn-primary">Actualitzar</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <?php include '../foot.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>