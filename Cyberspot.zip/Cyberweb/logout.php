<?php
// Incloure configuració
require_once 'config.php';

// Destruir la sessió
session_unset();
session_destroy();

// Redirigir a la pàgina principal
redirect("index.php");
?>